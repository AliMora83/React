import React from "react"

export default function Navbar() {
    return (
        <nav>
            <img src="../images/nklogo.png" className="nav--icon" />
            <h3 className="nav--logo_text">VE</h3>
            <h4 className="nav--title">REACT PROJECT 1</h4>
        </nav>
    )
}

