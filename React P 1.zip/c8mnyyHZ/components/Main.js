import React from "react"

export default function Main() {
    return (
        <main>
            <h1 className="main--title">WELCOME TO NAMKA</h1>
            <p className="body--text"> Our aim is to CONNECT LOCAL BUSINESS TO LOCAL USERS. <br />
            A platform with the latest techologies in <b>CODE TO ASSIST</b> <br />Small Businesses on the Network.
            </p>
            <ul className="main--facts">
                <li>Was first released in <b>2017</b></li>
                <li>Was originally created by <b>Ali Mora</b></li>
                <li>Software Solution by <b>Open Mind Industries</b></li>
            </ul>
        </main>
    )
};