import React from "react"

export default function Footer() {
    return (
        <nav>
            <img src="../images/nklogo.png" className="nav--icon" />
            <h6 className="nav--logo_text">VIRTUAL ECOSYSTEM</h6>
            <h4 className="foot--title">OPEN MIND INDUSTRIES</h4>
        </nav>
    )
}